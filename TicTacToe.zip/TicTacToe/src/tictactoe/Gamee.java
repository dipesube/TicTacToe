/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;




/**
 *
 * @author Geust
 */
public class Gamee {
    
    char[][] board = new char[3][3];
    boolean choice = true;
    int scorex = 0;
    int scoreo = 0;
    int mode;
    String turn = "X";
    int draw = 0;
    boolean winner = false;
    boolean Draw = false;
    public Gamee() { //constructor
        

    }
    
}
